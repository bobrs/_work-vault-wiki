# Consent-gated FSM scaffold

Minimal implementation for the OSF preregistered study draft: **Explicit Consent as a Stability-Enhancing State Transition**.

## Run modes

### Pilot/debug
Use for plumbing, sanity checks, parameter inspection, and code debugging only.

```bash
python src/consent_fsm.py \
  --config configs/20260603__CONSENT_CYBERNETICS__CONFIG__PILOT_DEBUG__V0__consent_fsm.json \
  --out-dir results
```

### Confirmatory
Do not run until the confirmatory config is reviewed, frozen, and intentionally invoked.

```bash
python src/consent_fsm.py \
  --config configs/20260603__CONSENT_CYBERNETICS__CONFIG__CONFIRMATORY_LOCKED_TEMPLATE__V0__consent_fsm.json \
  --out-dir results \
  --confirmatory-ok
```

The script refuses confirmatory configs unless `--confirmatory-ok` is passed.

## Current model

Two matched finite-state synthetic event-stream conditions are generated:

- `control`: no explicit consent-gated state transition after the matched gate time.
- `consent_gated`: the transition table changes after the matched gate time by routing ambiguous interactions through `consent_check`.

Primary debug metrics:

- pre-gate conditional entropy, `H(S_t+1 | S_t)`
- post-gate conditional entropy
- entropy change, post minus pre
- `delta_h_bits`: post-gate conditional entropy minus pre-gate conditional entropy
- `surprisal_residual_bits`: diagnostic post-gate mean surprisal relative to a pre-gate baseline predictor, minus pre-gate baseline surprisal
- simple bootstrap CI for consent-gated minus control condition differences

Pilot note: if the consent manipulation introduces a new symbolic state, a pre-gate surprisal model can penalize the gate itself as novelty. Treat `surprisal_residual_bits` as diagnostic unless this modeling choice is explicitly locked before confirmatory execution.

## Guardrail

Pilot/debug outputs are not confirmatory evidence. Confirmatory outputs are only interpretable if the config was locked before execution and no optional stopping or tuning was performed after seeing results.
