#!/usr/bin/env python3
"""
Minimal finite-state simulation for:
Explicit Consent as a Stability-Enhancing State Transition
First run: consent-gated synthetic event streams.

Design guardrail:
- pilot/debug runs and confirmatory runs are separate run modes.
- confirmatory configs require --confirmatory-ok and emit a config hash.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import random
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

State = str
Condition = str

STATES: Tuple[State, ...] = (
    "idle",
    "request",
    "consent_check",
    "share",
    "process",
    "complete",
    "error",
    "collapse",
)

BASE_TRANSITIONS: Dict[State, Dict[State, float]] = {
    "idle": {"idle": 0.25, "request": 0.55, "error": 0.05, "complete": 0.15},
    "request": {"share": 0.45, "process": 0.25, "idle": 0.15, "error": 0.15},
    "consent_check": {"share": 0.55, "idle": 0.25, "error": 0.10, "process": 0.10},
    "share": {"process": 0.60, "complete": 0.15, "request": 0.10, "error": 0.15},
    "process": {"complete": 0.50, "request": 0.20, "share": 0.10, "error": 0.20},
    "complete": {"idle": 0.70, "request": 0.20, "error": 0.10},
    "error": {"idle": 0.40, "request": 0.20, "collapse": 0.25, "process": 0.15},
    "collapse": {"idle": 0.55, "error": 0.25, "request": 0.20},
}

# After the matched gate time, the control condition remains broad/ambiguous.
CONTROL_POST_TRANSITIONS: Dict[State, Dict[State, float]] = BASE_TRANSITIONS

# After the gate time, the consent condition routes ambiguous interactions through a consent_check.
# This is the minimal manipulation: it changes transition structure, not merely labels events.
CONSENT_POST_TRANSITIONS: Dict[State, Dict[State, float]] = {
    "idle": {"idle": 0.30, "request": 0.62, "complete": 0.08},
    "request": {"consent_check": 0.78, "idle": 0.12, "error": 0.10},
    "consent_check": {"share": 0.74, "idle": 0.18, "error": 0.08},
    "share": {"process": 0.78, "complete": 0.14, "error": 0.08},
    "process": {"complete": 0.72, "request": 0.12, "error": 0.16},
    "complete": {"idle": 0.82, "request": 0.14, "error": 0.04},
    "error": {"idle": 0.62, "request": 0.18, "collapse": 0.10, "process": 0.10},
    "collapse": {"idle": 0.72, "error": 0.18, "request": 0.10},
}


def normalize(row: Mapping[State, float]) -> Dict[State, float]:
    total = float(sum(row.values()))
    if total <= 0:
        raise ValueError("Transition row has non-positive total probability")
    return {k: v / total for k, v in row.items()}


def sample_next(rng: random.Random, probs: Mapping[State, float]) -> State:
    x = rng.random()
    cdf = 0.0
    last = None
    for state, prob in normalize(probs).items():
        cdf += prob
        last = state
        if x <= cdf:
            return state
    assert last is not None
    return last


def transition_table(condition: Condition, t: int, gate_time: int) -> Dict[State, Dict[State, float]]:
    if t < gate_time:
        return BASE_TRANSITIONS
    if condition == "control":
        return CONTROL_POST_TRANSITIONS
    if condition == "consent_gated":
        return CONSENT_POST_TRANSITIONS
    raise ValueError(f"Unknown condition: {condition}")


def maybe_apply_perturbation(
    rng: random.Random,
    condition: Condition,
    state: State,
    t: int,
    perturbation_time: int,
    perturbation_strength: float,
) -> State:
    """Injects matched post-gate noise. Consent-gated condition has partial damping."""
    if t < perturbation_time:
        return state
    strength = perturbation_strength * (0.65 if condition == "consent_gated" else 1.0)
    if rng.random() < strength:
        return rng.choice(["error", "collapse", "request"])
    return state


def simulate_stream(
    *,
    seed: int,
    condition: Condition,
    length: int,
    gate_time: int,
    perturbation_time: int,
    perturbation_strength: float,
) -> List[State]:
    rng = random.Random(seed)
    states = ["idle"]
    for t in range(length - 1):
        table = transition_table(condition, t, gate_time)
        current = states[-1]
        nxt = sample_next(rng, table[current])
        nxt = maybe_apply_perturbation(rng, condition, nxt, t, perturbation_time, perturbation_strength)
        states.append(nxt)
    return states


def transition_counts(states: Sequence[State]) -> Dict[State, Counter]:
    counts: Dict[State, Counter] = defaultdict(Counter)
    for a, b in zip(states[:-1], states[1:]):
        counts[a][b] += 1
    return counts


def conditional_entropy(states: Sequence[State]) -> float:
    """Empirical conditional entropy H(S_t+1 | S_t), in bits."""
    counts = transition_counts(states)
    total_transitions = max(1, len(states) - 1)
    h = 0.0
    for prev, row in counts.items():
        row_total = sum(row.values())
        if row_total == 0:
            continue
        row_h = 0.0
        for count in row.values():
            p = count / row_total
            row_h -= p * math.log2(p)
        h += (row_total / total_transitions) * row_h
    return h


def fit_transition_model(states: Sequence[State], alpha: float = 1.0) -> Dict[State, Dict[State, float]]:
    """Laplace-smoothed predictive model trained on a stream segment."""
    counts = transition_counts(states)
    model: Dict[State, Dict[State, float]] = {}
    for prev in STATES:
        row = counts.get(prev, Counter())
        denom = sum(row.values()) + alpha * len(STATES)
        model[prev] = {nxt: (row.get(nxt, 0) + alpha) / denom for nxt in STATES}
    return model


def mean_surprisal(states: Sequence[State], model: Mapping[State, Mapping[State, float]]) -> float:
    vals: List[float] = []
    for a, b in zip(states[:-1], states[1:]):
        p = model[a][b]
        vals.append(-math.log2(max(p, 1e-12)))
    return sum(vals) / len(vals) if vals else float("nan")


def collapse_persistence(states: Sequence[State], start: int) -> int:
    """Simple secondary/debug metric: count collapse states after perturbation."""
    return sum(1 for s in states[start:] if s == "collapse")


def run_one(seed: int, condition: Condition, cfg: Mapping[str, object]) -> Dict[str, object]:
    length = int(cfg["stream_length"])
    gate_time = int(cfg["gate_time"])
    perturbation_time = int(cfg["perturbation_time"])
    perturbation_strength = float(cfg["perturbation_strength"])
    states = simulate_stream(
        seed=seed,
        condition=condition,
        length=length,
        gate_time=gate_time,
        perturbation_time=perturbation_time,
        perturbation_strength=perturbation_strength,
    )
    pre = states[:gate_time]
    post = states[gate_time:]
    baseline_model = fit_transition_model(pre, alpha=float(cfg.get("laplace_alpha", 1.0)))
    pre_entropy = conditional_entropy(pre)
    post_entropy = conditional_entropy(post)
    expected_baseline_surprisal = mean_surprisal(pre, baseline_model)
    observed_post_surprisal = mean_surprisal(post, baseline_model)
    return {
        "seed": seed,
        "condition": condition,
        "run_type": cfg["run_type"],
        "stream_length": length,
        "gate_time": gate_time,
        "perturbation_time": perturbation_time,
        "pre_entropy_bits": pre_entropy,
        "post_entropy_bits": post_entropy,
        "entropy_change_bits": post_entropy - pre_entropy,
        "baseline_surprisal_bits": expected_baseline_surprisal,
        "post_surprisal_bits": observed_post_surprisal,
        "surprisal_residual_bits": observed_post_surprisal - expected_baseline_surprisal,
        "delta_h_bits": post_entropy - pre_entropy,
        "collapse_persistence_count": collapse_persistence(states, perturbation_time),
    }


def mean(xs: Iterable[float]) -> float:
    vals = list(xs)
    return sum(vals) / len(vals) if vals else float("nan")


def bootstrap_ci_difference(
    rows: Sequence[Mapping[str, object]],
    metric: str,
    group_a: str,
    group_b: str,
    rng_seed: int,
    n_boot: int,
) -> Dict[str, float]:
    """Difference = mean(group_a) - mean(group_b)."""
    rng = random.Random(rng_seed)
    a = [float(r[metric]) for r in rows if r["condition"] == group_a]
    b = [float(r[metric]) for r in rows if r["condition"] == group_b]
    observed = mean(a) - mean(b)
    boots: List[float] = []
    for _ in range(n_boot):
        aa = [rng.choice(a) for _ in a]
        bb = [rng.choice(b) for _ in b]
        boots.append(mean(aa) - mean(bb))
    boots.sort()
    lo = boots[int(0.025 * (len(boots) - 1))]
    hi = boots[int(0.975 * (len(boots) - 1))]
    return {"difference": observed, "ci95_low": lo, "ci95_high": hi}


def summarize(rows: Sequence[Mapping[str, object]], cfg: Mapping[str, object]) -> Dict[str, object]:
    metrics = ["pre_entropy_bits", "post_entropy_bits", "entropy_change_bits", "delta_h_bits", "collapse_persistence_count"]
    by_condition: Dict[str, Dict[str, float]] = {}
    for condition in ["control", "consent_gated"]:
        subset = [r for r in rows if r["condition"] == condition]
        by_condition[condition] = {f"mean_{m}": mean(float(r[m]) for r in subset) for m in metrics}
        by_condition[condition]["n_streams"] = len(subset)
    comparisons = {
        "consent_minus_control_delta_h_bits": bootstrap_ci_difference(
            rows, "delta_h_bits", "consent_gated", "control", int(cfg["bootstrap_seed"]), int(cfg["n_bootstrap"])
        ),
        "consent_minus_control_post_entropy_bits": bootstrap_ci_difference(
            rows, "post_entropy_bits", "consent_gated", "control", int(cfg["bootstrap_seed"]) + 1, int(cfg["n_bootstrap"])
        ),
    }
    return {
        "run_type": cfg["run_type"],
        "claim_status": "DEBUG_ONLY_NOT_CONFIRMATORY" if cfg["run_type"] == "pilot_debug" else "CONFIRMATORY_CANDIDATE",
        "by_condition": by_condition,
        "comparisons": comparisons,
        "interpretation_guardrail": (
            "Pilot/debug output is for plumbing, sanity checks, and parameter inspection only. "
            "Do not use pilot/debug results as preregistered confirmatory evidence."
            if cfg["run_type"] == "pilot_debug"
            else "Confirmatory output should be interpreted only if config was locked before execution."
        ),
    }


def load_config(path: Path) -> Dict[str, object]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        return json.loads(text)
    raise ValueError("Use a .json config for this minimal scaffold")


def hash_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_outputs(rows: Sequence[Mapping[str, object]], summary: Mapping[str, object], out_dir: Path, prefix: str) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    row_path = out_dir / f"{prefix}__stream_metrics.csv"
    summary_path = out_dir / f"{prefix}__summary.json"
    if rows:
        with row_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Consent-gated FSM synthetic event stream simulation")
    parser.add_argument("--config", required=True, help="Path to pilot_debug or confirmatory JSON config")
    parser.add_argument("--out-dir", default="results", help="Output directory")
    parser.add_argument("--confirmatory-ok", action="store_true", help="Required to run confirmatory config")
    args = parser.parse_args()

    config_path = Path(args.config)
    cfg = load_config(config_path)
    run_type = cfg.get("run_type")
    if run_type not in {"pilot_debug", "confirmatory"}:
        raise SystemExit("Config run_type must be 'pilot_debug' or 'confirmatory'")
    if run_type == "confirmatory" and not args.confirmatory_ok:
        raise SystemExit("Refusing confirmatory run without --confirmatory-ok. This prevents accidental peeking/optional stopping.")

    seeds = [int(s) for s in cfg["seeds"]]
    rows: List[Dict[str, object]] = []
    for seed in seeds:
        for condition in ["control", "consent_gated"]:
            rows.append(run_one(seed, condition, cfg))

    summary = summarize(rows, cfg)
    summary["config_path"] = str(config_path)
    summary["config_sha256"] = hash_file(config_path)
    summary["n_rows"] = len(rows)

    prefix = str(cfg.get("output_prefix", run_type))
    write_outputs(rows, summary, Path(args.out_dir), prefix)
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
