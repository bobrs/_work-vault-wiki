# OSF Preregistration

**Research Program:** Consentful Cybernetics  
**Program Spine:** Consent is not merely an ethical constraint on intelligence. It is how intelligence remains coherent as it scales.  
**Format:** Normalized OSF-ready preregistration draft  
**Status:** Draft for registration/upload  


## Title

**Consent as a Cross-Substrate Invariant: Measuring Re-key Costs and Influence Radius in Multi-Agent Systems**

## 1. Research Question

Do consent boundaries function as a cross-substrate invariant that constrains which interactions are allowed to close loops between agents, and are consent updates disproportionately costly because they require re-keying shared reality?

## 2. Theoretical Background and Rationale

Across domains including brains, norms, law, cryptography, protocols, culture, and machines, agents coordinate through repeated interactions that update shared state. This study proposes that **consent** can be modeled as an admissibility constraint on loop-closure events.

When consent changes through grant, withdrawal, narrowing, or revocation, systems must re-key shared expectations, permissions, access patterns, and dependent states. This re-keying is hypothesized to be the primary driver of the observed coordination cost associated with consent change.

## 3. Hypotheses

**H1 — Invariant role hypothesis:** In multi-agent systems with shared mutable state, there exists a consent-like variable that partitions interactions into admissible vs inadmissible loop closures. Violations of this boundary will produce measurable coherence or coordination costs.

**H2 — Re-key cost hypothesis:** Consent updates incur disproportionately higher coordination costs than routine interactions because they re-key shared reality.

**H3 — Scaling hypothesis:** The cost of a consent update scales with the influence radius, defined as the number and strength of dependent shared states affected by the update.

**H4 — Design mitigation hypothesis:** Systems designed to minimize influence radius will exhibit lower Revocation Cost Ratios without increasing the rate of consent violations.

## 4. Operational Definitions

**Agent:** An entity whose internal state predicts its future actions better than external observation alone.

**Loop closure:** An interaction that results in a mutual state update between agents.

**Consent state:** The current set of admissible interaction types or scopes for an agent.

**Consent update:** Any modification to consent state, including grant, withdrawal, narrowing, or revocation.

**Influence radius:** The number and strength of dependent shared states, including permissions, expectations, data, and roles, affected by a consent update.

**Coordination cost:** Measured time, communication overhead, computational work, or number of state changes required to restore system stability.

**Revocation Cost Ratio (RCR):**

`RCR = Cost of consent update / Median cost of routine interaction`

## 5. Study Design

The primary empirical focus will be on protocol and cryptographic coordination systems, where consent boundaries can be precisely instrumented.

Two simulated or implemented systems will be compared under identical interaction workloads:

- **Localized-Consent System (LCS):** Scoped permissions, short-lived capabilities, local revocation, and compartmentalized state.
- **Global-Consent System (GCS):** Broad permissions, long-lived keys, centralized policy, and global invalidation on revocation.

## 6. Data Collection

Data will be collected through instrumentation of simulation or protocol logs. For each system, the following will be measured:

- Cost of routine interactions.
- Cost of consent updates, especially revocations.
- Revocation Cost Ratio (RCR).
- Influence radius per consent update.
- Time to restore admissible interaction state after revocation.
- Rate of continued inadmissible interactions after withdrawal, defined as violation persistence.

## 7. Measures and Variables

### 7.1 Independent / Design Variables

- System architecture: LCS vs GCS.
- Influence radius of each consent update.
- Type of consent update, including grant, narrowing, withdrawal, or revocation.

### 7.2 Dependent Variables

- Coordination cost.
- RCR.
- Time to restore admissible interaction state.
- Violation persistence.
- Coherence or stability costs following inadmissible loop closure.

## 8. Analysis Plan

The analysis will:

- Compare mean and distributional RCR between LCS and GCS systems.
- Test correlation between influence radius and coordination cost.
- Evaluate whether reductions in RCR are associated with increases in violation rates.
- Use non-parametric tests where distributional assumptions are violated.

## 9. Criteria for Support, Revision, or Falsification

The hypotheses will be considered supported if:

- Consent updates exhibit higher coordination cost than routine interactions.
- Coordination cost scales with influence radius.
- Localized-consent designs reduce RCR without increasing violation persistence.

The hypotheses will be revised or rejected if:

- Consent updates do not exhibit higher coordination cost than routine interactions.
- Coordination cost does not scale with influence radius.
- Systems with reduced influence radius show higher violation persistence or instability.
- No consent-like admissibility variable can be identified in the studied systems.

## 10. Scope Conditions and Limitations

This preregistration applies to systems with:

- Distinct semi-autonomous agents.
- Repeated interactions.
- Shared mutable state.

The claims do not extend to purely agentless or fully deterministic physical systems.

## 11. Ethical Considerations

This study focuses on simulated or protocol-level systems. If applied to real-world interaction logs in later phases, privacy, de-identification, access control, and consent for data use will be specified before analysis.

## 12. Transparency and Deviations

All deviations from this preregistered plan will be explicitly documented and justified in subsequent reporting.

## 13. Data and Code Availability

All analysis code and synthetic data, where applicable, will be made publicly available.

## 14. Summary Statement

This preregistration formalizes a testable claim that consent functions as a cross-substrate invariant governing admissible loop closures, and that the cost of consent change arises from re-keying shared reality. The Revocation Cost Ratio provides a falsifiable quantitative handle on this claim.
