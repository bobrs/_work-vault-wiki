import type { CollectionEntry } from 'astro:content';

export type Project = CollectionEntry<'projects'>;
export type Artifact = CollectionEntry<'artifacts'>;
export type Stack = CollectionEntry<'stacks'>;
export type Branch = CollectionEntry<'branches'>;
export type Lantern = Project | Artifact | Stack | Branch;

export function visible<T extends { data: { visibility?: string } }>(items: T[]) {
  return items.filter((item) => item.data.visibility !== 'private');
}

export function publicOnly<T extends { data: { visibility?: string } }>(items: T[]) {
  return items.filter((item) => item.data.visibility === undefined || item.data.visibility === 'public');
}

export function sortByOrderTitle<T extends { data: { order?: number; title: string } }>(items: T[]) {
  return [...items].sort((a, b) => {
    const order = (a.data.order ?? 999) - (b.data.order ?? 999);
    if (order !== 0) return order;
    return a.data.title.localeCompare(b.data.title);
  });
}

export function groupBy<T>(items: T[], keyFn: (item: T) => string | undefined) {
  return items.reduce<Record<string, T[]>>((acc, item) => {
    const key = keyFn(item) || 'unclassified';
    acc[key] ||= [];
    acc[key].push(item);
    return acc;
  }, {});
}

export function uniqueSorted(values: string[]) {
  return Array.from(new Set(values.filter(Boolean))).sort((a, b) => a.localeCompare(b));
}

export function entrySlug(entry: { id: string }) {
  return entry.id.replace(/\.md$/, '');
}

export function projectUrl(project: Project) {
  return `/projects/${entrySlug(project)}/`;
}

export function artifactUrl(artifact: Artifact) {
  return `/artifacts/${entrySlug(artifact)}/`;
}

export function stackUrl(stack: Stack | string) {
  const slug = typeof stack === 'string' ? stack : entrySlug(stack);
  return `/stacks/${slug}/`;
}

export function branchUrl(branch: Branch | string) {
  const slug = typeof branch === 'string' ? branch : entrySlug(branch);
  return `/branches/${slug}/`;
}

export function statusUrl(status: string) {
  return `/status/${status}/`;
}

export function labelize(value: string) {
  return value
    .split('-')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

export function domainSummary(project: Project) {
  if (project.data.domains?.length) return project.data.domains;
  if (project.data.url) {
    try {
      const domain = new URL(project.data.url).hostname.replace(/^www\./, '');
      return [{ domain, role: 'canonical', status: 'unknown', decision: 'review' }];
    } catch {
      return [];
    }
  }
  return [];
}

export function allTags(...groups: Array<Array<{ data: { tags?: string[] } }>>) {
  return uniqueSorted(groups.flat().flatMap((entry) => entry.data.tags ?? []));
}
