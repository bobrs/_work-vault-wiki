# POLEMEMELOP Astro Constellation Scaffold v0.5

This version adds the identity layer prep:

- Styled POLEMEMELOP wordmark component
- Circular sigil and bracketed system mark component variants
- `The POLEMEMELOP Marks` artifact card
- Oversized watermark glyph component
- Watermark glyph pass across homepage, constellation, stacks, artifacts, branches, project pages, and keeper index

## Run

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## New files

```txt
src/components/LogoMark.astro
src/components/WatermarkGlyph.astro
src/content/artifacts/polememelop-marks.md
```

## Identity strategy

Use the text wordmark now:

```html
<span class="wordmark-hero">pŏlēmēmēlŏp</span>
```

Later, replace or augment with SVGs if the original marks are vectorized.

## Watermark glyph strategy

Any major layout region can become a watermark host:

```astro
<section class="watermark-host">
  <WatermarkGlyph glyph="ō" position="right" tone="gold" size="large" />
  ...content...
</section>
```

Supported props:

```txt
glyph: any glyph/string
position: right | left | bottom | center
tone: gold | soft | strong | purple | orange
size: small | default | large
```
