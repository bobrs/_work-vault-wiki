import { defineCollection } from 'astro:content';
import { glob } from 'astro/loaders';
import { z } from 'astro/zod';

const projectStatuses = [
  'live',
  'seed',
  'draft',
  'dormant',
  'parked',
  'redirect',
  'deprecated',
  'needs-review'
] as const;

const projectTypes = [
  'site',
  'essay-vault',
  'protocol',
  'product',
  'project',
  'company',
  'initiative',
  'practice',
  'lexicon',
  'tool',
  'archive',
  'framework',
  'prototype'
] as const;

const visibility = ['public', 'lantern', 'private'] as const;

const domainSchema = z.object({
  domain: z.string(),
  role: z.enum(['canonical', 'alias', 'redirect', 'parked', 'defensive', 'deprecated']).default('canonical'),
  status: z.enum(['active', 'grace', 'expired', 'unknown']).default('unknown'),
  expires: z.string().optional(),
  auto_renew: z.boolean().optional(),
  decision: z.enum(['keep', 'review', 'redirect', 'eliminate']).default('review'),
  notes: z.string().optional()
});

const commonLanternFields = {
  title: z.string(),
  glyph: z.string().default('✦'),
  glyph_label: z.string().optional(),
  description: z.string(),
  branch: z.string().default('unclassified'),
  stack: z.string().optional(),
  order: z.number().default(999),
  tags: z.array(z.string()).default([]),
  visibility: z.enum(visibility).default('public'),
  featured: z.boolean().default(false),
  keeper_note: z.string().optional(),
  next_action: z.string().optional(),
  canonical: z.boolean().default(false)
};

const projects = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/projects' }),
  schema: z.object({
    ...commonLanternFields,
    url: z.string().url().optional(),
    status: z.enum(projectStatuses),
    type: z.enum(projectTypes),
    parent: z.string().optional(),
    domains: z.array(domainSchema).default([]),
    related_projects: z.array(z.string()).default([]),
    related_artifacts: z.array(z.string()).default([]),
    health: z.enum(['alive', 'forming', 'dormant', 'stale', 'broken', 'unknown']).default('unknown'),
    priority: z.number().default(3),
    last_reviewed: z.string().optional()
  })
});

const artifactTypes = [
  'parable',
  'essay',
  'one-pager',
  'teaser',
  'manifesto',
  'framework',
  'protocol-vision',
  'prototype',
  'lexicon-entry',
  'playbook',
  'story',
  'spec',
  'identity-artifact'
] as const;

const artifacts = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/artifacts' }),
  schema: z.object({
    ...commonLanternFields,
    subtitle: z.string().optional(),
    artifact_type: z.enum(artifactTypes),
    status: z.enum(['live', 'seed', 'draft', 'dormant', 'needs-review']).default('seed'),
    related_projects: z.array(z.string()).default([]),
    related_artifacts: z.array(z.string()).default([]),
    source: z.string().optional(),
    sections: z.array(z.object({
      title: z.string(),
      content: z.string()
    })).default([])
  })
});

const stacks = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/stacks' }),
  schema: z.object({
    title: z.string(),
    glyph: z.string().default('🪺'),
    description: z.string(),
    branch: z.string(),
    status: z.enum(['active', 'seed', 'dormant', 'needs-review']).default('active'),
    visibility: z.enum(visibility).default('public'),
    display: z.enum(['collapsible', 'expanded', 'hidden']).default('collapsible'),
    order: z.number().default(999),
    featured: z.boolean().default(false),
    tags: z.array(z.string()).default([]),
    keeper_note: z.string().optional(),
    next_action: z.string().optional()
  })
});

const branches = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/branches' }),
  schema: z.object({
    title: z.string(),
    glyph: z.string().default('✦'),
    description: z.string(),
    order: z.number().default(999),
    tags: z.array(z.string()).default([])
  })
});

export const collections = { projects, artifacts, stacks, branches };
