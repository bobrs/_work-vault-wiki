---
title: HumanKey
status: seed
type: protocol
branch: trust-consent
parent: deeptrust
order: 140
tags: [identity, key, trust, substrate]
visibility: public
featured: false
description: Substrate anchor of identity and cryptographic root-of-trust for loop-scoped presence and consent.
keeper_note: Needs clearer public explanation that avoids crypto maximalism.
next_action: Decide whether this is protocol page under DeepTrust or its own site.
canonical: true
glyph: "🔑"
stack: "consent-stack"
health: "forming"
priority: 2
---

HumanKey is the identity anchor beneath loop-scoped trust: a root for presence without collapsing identity into a global profile.
