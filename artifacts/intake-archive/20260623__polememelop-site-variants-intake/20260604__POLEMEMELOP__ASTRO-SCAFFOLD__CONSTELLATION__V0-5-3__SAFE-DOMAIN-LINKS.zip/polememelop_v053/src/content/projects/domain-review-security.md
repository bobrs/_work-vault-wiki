---
title: "Security Domain Review"
glyph: "🛡️"
status: "needs-review"
type: "archive"
branch: "security-tools"
stack: "deeptrust-security-stack"
parent: "polememelop"
order: 900
tags: ["domains", "security", "review", "inventory"]
visibility: "lantern"
featured: false
description: "Keeper-only holding card for security-adjacent domains that may become tools, redirects, or eliminated inventory."
keeper_note: "Extracted from Namecheap screenshots. Do not publicize until classified."
next_action: "Sort each domain as keep, redirect, or eliminate."
canonical: false
domains:
  - domain: "alreadyhacked.com"
    role: "parked"
    status: "active"
    expires: "2026-08-05"
    auto_renew: true
    decision: "review"
  - domain: "auditplug.com"
    role: "parked"
    status: "active"
    expires: "2026-08-16"
    auto_renew: true
    decision: "review"
  - domain: "ghostplug.com"
    role: "parked"
    status: "active"
    expires: "2026-07-25"
    auto_renew: true
    decision: "review"
  - domain: "ghostsentry.com"
    role: "parked"
    status: "active"
    expires: "2026-07-21"
    decision: "review"
  - domain: "evilplug.com"
    role: "parked"
    status: "active"
    expires: "2026-08-25"
    auto_renew: true
    decision: "review"
  - domain: "navpointer.com"
    role: "parked"
    status: "active"
    expires: "2031-04-02"
    decision: "review"
  - domain: "netsgone.com"
    role: "parked"
    status: "active"
    decision: "review"
  - domain: "netsgone.org"
    role: "parked"
    status: "active"
    expires: "2027-01-02"
    decision: "review"
health: "unknown"
priority: 3
---

This card keeps the security-domain inventory visible without promoting it publicly.
