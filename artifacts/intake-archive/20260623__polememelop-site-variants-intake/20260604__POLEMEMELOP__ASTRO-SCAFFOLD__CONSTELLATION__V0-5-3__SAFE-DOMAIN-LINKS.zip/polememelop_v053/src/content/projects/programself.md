---
title: ProgramSelf
url: https://programself.com
status: live
type: practice
branch: self-practice
parent: polememelop
order: 100
tags: [agency, ai-fluency, self-as-os, tooling]
visibility: public
featured: false
description: Agency, self-as-OS, AI fluency, and practical tooling for deliberate self-direction.
keeper_note: Potentially the most practical bridge for technical visitors.
next_action: Decide relation to MobiusSelf and Rewild Yourself in navigation.
canonical: true
glyph: "⌘"
stack: "self-stack"
domains:
  - domain: "programself.com"
    role: "canonical"
    status: "active"
    expires: "2026-12-12"
    auto_renew: false
    decision: "keep"
health: "forming"
priority: 2
---

ProgramSelf is the agency and tooling branch: self-as-OS, AI fluency, and deliberate interaction with systems.
