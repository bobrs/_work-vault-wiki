---
title: Field Pragmatics
url: https://fieldpragmatics.com
status: live
type: practice
branch: deep-atlas
parent: polememelop
order: 110
tags: [pragmatics, translation, meaning-in-use]
visibility: public
featured: false
description: "Meaning-in-use: the translation layer between theory and practice, field and artifact, intent and operation."
keeper_note: Good bridge between abstract canon and applied implementation.
next_action: Decide whether Field Pragmatics is a branch label, a method, a site, or all three.
canonical: true
glyph: "🜁"
stack: "deep-atlas-stack"
domains:
  - domain: "fieldpragmatics.com"
    role: "canonical"
    status: "active"
    expires: "2027-05-28"
    auto_renew: false
    decision: "keep"
  - domain: "fieldprogramatics.com"
    role: "alias"
    status: "active"
    decision: "review"
health: "forming"
priority: 2
---

Field Pragmatics is the meaning-in-use layer: where high theory becomes operational without pretending context disappeared.
