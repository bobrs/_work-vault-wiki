---
title: "Culled Domains"
glyph: "🗑️"
status: "deprecated"
type: "archive"
branch: "unclassified"
parent: "polememelop"
order: 999
tags: ["domains", "eliminate", "inventory", "keeper"]
visibility: "lantern"
featured: false
description: "Keeper-only holding card for domains marked for elimination or non-renewal."
keeper_note: "These were explicitly marked as eliminable."
next_action: "Turn off auto-renew where appropriate and confirm no active dependency."
canonical: false
domains:
  - domain: "shoptaurusmoon.com"
    role: "deprecated"
    status: "active"
    expires: "2026-09-28"
    auto_renew: true
    decision: "eliminate"
  - domain: "solosentry.com"
    role: "deprecated"
    status: "active"
    expires: "2026-11-01"
    auto_renew: true
    decision: "eliminate"
  - domain: "tribalaccountingsolutions.com"
    role: "deprecated"
    status: "active"
    expires: "2026-09-05"
    auto_renew: true
    decision: "eliminate"
  - domain: "vpnplug.com"
    role: "deprecated"
    status: "active"
    expires: "2026-07-20"
    auto_renew: true
    decision: "eliminate"
  - domain: "nativeaccountingsolutions.com"
    role: "deprecated"
    status: "active"
    expires: "2026-09-05"
    auto_renew: true
    decision: "review"
health: "stale"
priority: 3
---

This lantern exists for keeper memory, not public navigation.
