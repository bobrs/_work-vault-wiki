---
title: "Witness Self"
glyph: "🜹"
url: "https://witnessself.com"
status: "seed"
type: "practice"
branch: "self-practice"
stack: "self-stack"
parent: "polememelop"
order: 30
tags: ["self", "witness", "attention", "practice"]
visibility: "public"
featured: true
description: "A Self Stack surface for witnessing the self without forcing, fixing, or collapsing it."
keeper_note: "Domain inventory seed."
next_action: "Clarify relation to MobiusSelf and ego stewardship."
domains:
  - domain: "witnessself.com"
    role: "canonical"
    status: "active"
    expires: "2027-05-30"
    auto_renew: false
    decision: "keep"
health: "forming"
priority: 2
---

Witness Self is part of the Self Stack.
