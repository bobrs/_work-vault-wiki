---
title: "Program You"
glyph: "⌘"
url: "https://programyou.online"
status: "seed"
type: "site"
branch: "self-practice"
stack: "self-stack"
parent: "programself"
order: 70
tags: ["self", "programming", "alias", "agency"]
visibility: "lantern"
featured: false
description: "A possible alias or public-facing variant for ProgramSelf."
keeper_note: "Likely alias to ProgramSelf."
next_action: "Decide canonical vs redirect."
domains:
  - domain: "programyou.online"
    role: "alias"
    status: "active"
    expires: "2026-12-12"
    auto_renew: false
    decision: "review"
health: "unknown"
priority: 3
---

Program You is an alias candidate.
