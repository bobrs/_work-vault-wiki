---
title: How One Thing Works
url: https://howonething.work
status: live
type: site
branch: public-pedagogy
parent: polememelop
order: 70
tags: [orientation, pedagogy, how-it-works]
visibility: public
featured: false
description: "Navigation and orientation lens for the ecosystem: a public way to understand one thing through many doors."
keeper_note: This may become the public index-facing translation layer for non-initiates.
next_action: Clarify whether it is parent of How* sites or sibling to HowLivingWorks.
canonical: true
glyph: "🌱"
stack: "how-works-stack"
domains:
  - domain: "howonething.work"
    role: "canonical"
    status: "active"
    decision: "keep"
health: "forming"
priority: 2
---

How One Thing Works is an orientation lens: a gentle way into the ecosystem for people who need less shimmer and more handrail.
