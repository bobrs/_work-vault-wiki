---
title: "How Consent Works"
glyph: "🝁"
url: "https://howconsentworks.com"
status: "seed"
type: "site"
branch: "public-pedagogy"
stack: "how-works-stack"
parent: "howonething"
order: 30
tags: ["how", "consent", "pedagogy", "public"]
visibility: "public"
featured: false
description: "A public pedagogy surface for consent as boundary flow control."
keeper_note: "Domain inventory seed."
next_action: "Write one-page public explainer."
domains:
  - domain: "howconsentworks.com"
    role: "canonical"
    status: "active"
    expires: "2026-12-24"
    auto_renew: false
    decision: "keep"
health: "forming"
priority: 3
---

How Consent Works is part of the How Works Stack.
