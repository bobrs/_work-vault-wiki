---
title: "Rest Self"
glyph: "🛌"
url: "https://restself.com"
status: "seed"
type: "practice"
branch: "self-practice"
stack: "self-stack"
parent: "polememelop"
order: 20
tags: ["self", "rest", "nervous-system", "practice"]
visibility: "public"
featured: true
description: "A Self Stack surface for rest, restoration, and capacity-aware return."
keeper_note: "Domain inventory seed."
next_action: "Write the public rest-practice promise."
domains:
  - domain: "restself.com"
    role: "canonical"
    status: "active"
    expires: "2027-05-31"
    auto_renew: false
    decision: "keep"
health: "forming"
priority: 2
---

Rest Self is part of the Self Stack.
