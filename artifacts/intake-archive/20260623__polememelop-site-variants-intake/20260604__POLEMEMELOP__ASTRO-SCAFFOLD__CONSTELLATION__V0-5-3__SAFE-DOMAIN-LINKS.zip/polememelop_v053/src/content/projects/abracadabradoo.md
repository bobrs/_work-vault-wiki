---
title: Abracadabradoo
status: seed
type: protocol
branch: trust-consent
parent: humankey
order: 150
tags: [messaging, witness, aead, semantic-payload]
visibility: public
featured: false
description: Secure messaging and witness layer for loop-specific semantic payload transport.
keeper_note: Name has playful power; public explanation needs to preserve that without seeming unserious.
next_action: Add protocol summary and relationship to LoopLink/FractalIdentity.
canonical: true
glyph: "🜁"
stack: "consent-stack"
domains:
  - domain: "abracadabracadoo.com"
    role: "alias"
    status: "active"
    expires: "2027-03-30"
    auto_renew: false
    decision: "review"
  - domain: "abracadoo.app"
    role: "alias"
    status: "active"
    expires: "2027-06-01"
    auto_renew: false
    decision: "keep"
health: "forming"
priority: 2
---

Abracadabradoo is the secure message-and-witness layer: payloads, presence, and loop-specific continuity.
