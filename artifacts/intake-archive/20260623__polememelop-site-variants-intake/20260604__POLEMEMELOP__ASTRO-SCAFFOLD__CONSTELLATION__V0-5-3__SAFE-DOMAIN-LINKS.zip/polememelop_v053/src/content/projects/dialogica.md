---
title: DeepTrust Dialogica
url: https://dialogica.io
status: live
type: protocol
branch: trust-consent
parent: deeptrust
order: 40
tags: [dialogue, agents, negotiation, governance, audit]
visibility: public
featured: true
description: Protocol-native communication platform for auditable structured dialogue between humans and autonomous agents.
keeper_note: Key use cases include AI-mediated negotiation, dispute resolution, and civic dialogue.
next_action: Ensure Dialogica is cross-linked under both DeepTrust and governance/continuity branches.
canonical: true
glyph: "💬"
stack: "consent-stack"
health: "forming"
priority: 2
---

Dialogica is the structured dialogue layer: routing, consent renegotiation, auditable commitments, and agent-mediated conversation.
