---
title: ULiUA
url: https://uliua.com
status: live
type: initiative
branch: meaning-meme
parent: polememelop
order: 20
tags: [unconditional-love, acceptance, automeme, culture]
visibility: public
featured: true
description: "Unconditional Love Includes Unconditional Acceptance: a love-based automeme designed to spread radical acceptance through culture."
keeper_note: First-class mission. Needs strong public path from POLEMEMELOP and reciprocal footer link back.
next_action: Align homepage language with official teaser and decide how much automeme machinery to expose.
canonical: true
glyph: "🌺"
stack: "meaning-meme-stack"
domains:
  - domain: "uliua.com"
    role: "canonical"
    status: "active"
    expires: "2026-12-12"
    auto_renew: false
    decision: "keep"
health: "alive"
priority: 1
---

ULiUA is the cultural-scale automeme: simple enough to say, deep enough to propagate, and built around unconditional acceptance.
