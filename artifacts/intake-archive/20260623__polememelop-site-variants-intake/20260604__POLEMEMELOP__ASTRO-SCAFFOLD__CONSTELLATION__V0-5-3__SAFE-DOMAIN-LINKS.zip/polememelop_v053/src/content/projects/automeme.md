---
title: AutoMeme
status: seed
type: project
branch: meaning-meme
parent: uliua
order: 170
tags: [automeme, culture, propagation, feedback]
visibility: public
featured: false
description: Self-sustaining, self-replicating memetic entity pattern for culture-scale propagation.
keeper_note: Consider whether AutoMeme is a concept under ULiUA or a reusable engine across multiple memes.
next_action: Rename slug/file if AutoMeme should have exact canonical casing and domain.
canonical: false
---

AutoMeme is the engine-pattern: a meme that speaks, evolves, funds, and propagates itself through feedback.
