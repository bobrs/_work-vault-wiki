---
title: Quantum Invariants
url: https://quantuminvariants.com
status: live
type: site
branch: deep-atlas
parent: polememelop
order: 120
tags: [invariants, theory, atlas, deep-structure]
visibility: public
featured: false
description: "Deep theory and atlas of invariants across domains: patterns that persist through transformation."
keeper_note: This is likely the deepest theory node. Avoid making it the front door.
next_action: Add clear relation to Canon of Persistence and Loop Theory.
canonical: true
glyph: "🜁"
stack: "deep-atlas-stack"
domains:
  - domain: "quantuminvariants.com"
    role: "canonical"
    status: "active"
    expires: "2026-12-03"
    auto_renew: false
    decision: "keep"
health: "forming"
priority: 2
---

Quantum Invariants is the deep atlas branch: invariant patterns across domains, transformations, and scales.
