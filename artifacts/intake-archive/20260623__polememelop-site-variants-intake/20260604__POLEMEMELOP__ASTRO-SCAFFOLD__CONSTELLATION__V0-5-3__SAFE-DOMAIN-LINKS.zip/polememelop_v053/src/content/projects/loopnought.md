---
title: LoopNought
url: https://loopnought.com
status: live
type: site
branch: loop-theory
parent: polememelop
order: 50
tags: [loop-0, canon, persistence, boundary]
visibility: public
featured: true
description: "Canonical Loop-0 origin site for the first non-trivial control loop: boundary, gated intake, storage, and feedback."
keeper_note: LoopNaught.com is an alias. Keep distinction or redirect strategy clear.
next_action: Add alias handling note and connect to Canon of Persistence page.
canonical: true
glyph: "🝳"
stack: "loop-stack"
domains:
  - domain: "loopnought.com"
    role: "canonical"
    status: "active"
    expires: "2026-11-08"
    auto_renew: false
    decision: "keep"
  - domain: "loopnaught.com"
    role: "alias"
    status: "active"
    expires: "2026-11-08"
    auto_renew: false
    decision: "redirect"
health: "forming"
priority: 2
---

LoopNought is the origin lantern for Loop-0: the smallest stable pattern of persistence through boundary and feedback.
