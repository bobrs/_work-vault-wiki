---
title: "How Self Works"
glyph: "🪞"
url: "https://howselfworks.com"
status: "seed"
type: "site"
branch: "public-pedagogy"
stack: "how-works-stack"
parent: "howonething"
order: 50
tags: ["how", "self", "pedagogy", "self-stack"]
visibility: "public"
featured: false
description: "A public pedagogy surface for selfhood as loop, mirror, witness, and practice."
keeper_note: "Bridge between How Works Stack and Self Stack."
next_action: "Define relation to MobiusSelf and WitnessSelf."
domains:
  - domain: "howselfworks.com"
    role: "canonical"
    status: "active"
    expires: "2026-12-24"
    auto_renew: true
    decision: "keep"
health: "forming"
priority: 3
---

How Self Works is part of the How Works Stack.
