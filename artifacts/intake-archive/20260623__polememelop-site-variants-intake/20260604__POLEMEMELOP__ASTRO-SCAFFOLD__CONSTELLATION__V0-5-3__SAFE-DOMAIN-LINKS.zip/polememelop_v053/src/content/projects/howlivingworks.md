---
title: How Living Works
status: seed
type: site
branch: public-pedagogy
parent: howonething
order: 180
tags: [life, persistence, canon, pedagogy]
visibility: public
featured: false
description: Public-facing explanation of the persistence canon across cells, selves, organizations, and civilizations.
keeper_note: Strong canon-aligned project; may be the cleanest public shadow of Loop-0.
next_action: Add domain if owned and draft starter copy.
canonical: true
---

How Living Works explains persistence without mysticism: boundary, intake, storage, routing, feedback, correction.
