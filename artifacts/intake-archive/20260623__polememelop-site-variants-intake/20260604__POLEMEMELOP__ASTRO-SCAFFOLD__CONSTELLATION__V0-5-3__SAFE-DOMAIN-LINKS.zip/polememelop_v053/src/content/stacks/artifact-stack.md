---
title: "Artifact Stack"
glyph: "🏮"
description: "Standalone meaning artifacts: parables, one-pagers, teasers, frameworks, and protocol visions."
branch: "root"
status: "active"
visibility: "public"
display: "expanded"
order: 90
featured: true
tags: ["artifacts", "cards", "lanterns"]
---
