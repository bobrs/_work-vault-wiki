---
title: "The Consent Stack"
glyph: "🝁"
description: "Projects and protocols for consent as boundary flow control: capability, handshake, refusal, witness, and renegotiation."
branch: "trust-consent"
status: "active"
visibility: "public"
display: "collapsible"
order: 30
featured: true
tags: ["consent", "boundary", "witness", "renegotiation"]
---
