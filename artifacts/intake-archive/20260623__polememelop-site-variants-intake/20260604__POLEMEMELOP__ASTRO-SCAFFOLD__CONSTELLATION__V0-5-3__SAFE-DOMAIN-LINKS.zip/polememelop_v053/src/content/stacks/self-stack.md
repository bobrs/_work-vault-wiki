---
title: "The Self Stack"
glyph: "🪞"
description: "A collapsible cluster of selfhood projects: accept, rest, witness, maintain, regulate, program, rewild, and return."
branch: "self-practice"
status: "active"
visibility: "public"
display: "collapsible"
order: 10
featured: true
tags: ["self", "rest", "witness", "regulation", "agency"]
keeper_note: "This is the first stack that proved the need for collapsible constellation clusters."
next_action: "Decide canonical surfaces and aliases for the Self domains."
---
