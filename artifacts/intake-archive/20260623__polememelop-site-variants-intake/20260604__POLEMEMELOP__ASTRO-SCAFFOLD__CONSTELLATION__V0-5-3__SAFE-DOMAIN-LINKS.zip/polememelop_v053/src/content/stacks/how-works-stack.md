---
title: "The How Works Stack"
glyph: "🌱"
description: "A public pedagogy cluster: small doors into big concepts through how-X-works domains."
branch: "public-pedagogy"
status: "active"
visibility: "public"
display: "collapsible"
order: 20
featured: true
tags: ["how", "public", "pedagogy", "explainers"]
next_action: "Choose the canonical parent: How One Thing Works or POLEMEMELOP."
---
