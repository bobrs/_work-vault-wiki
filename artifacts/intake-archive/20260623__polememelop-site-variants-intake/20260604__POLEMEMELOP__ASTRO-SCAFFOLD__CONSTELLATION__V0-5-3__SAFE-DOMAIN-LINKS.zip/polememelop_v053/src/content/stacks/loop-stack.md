---
title: "The Loop Stack"
glyph: "🝳"
description: "Loop-0, LoopNought, LoopNaught, loop language, loop games, and related recursive semantic systems."
branch: "loop-theory"
status: "active"
visibility: "public"
display: "collapsible"
order: 40
featured: true
tags: ["loop", "recursion", "loop-0", "semantic-loop"]
---
