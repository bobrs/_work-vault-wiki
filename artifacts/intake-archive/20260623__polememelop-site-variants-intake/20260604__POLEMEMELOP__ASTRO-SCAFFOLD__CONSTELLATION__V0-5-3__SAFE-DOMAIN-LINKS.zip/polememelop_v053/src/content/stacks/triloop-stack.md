---
title: "Triloop Stack"
glyph: "✴️"
description: "LoopLang, LoopStory, and LoopGame as three renderings of consent logic, narrative recursion, and playable agency."
branch: "loop-theory"
status: "seed"
visibility: "public"
display: "collapsible"
order: 80
featured: true
tags: ["looplang", "loopstory", "loopgame", "triloop"]
---
