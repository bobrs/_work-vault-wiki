---
title: "Embodiment"
glyph: "🌿"
description: "Body, nervous system, capacity, pacing, ritual technology, and physical prototypes that make consent tangible."
order: 80
tags: ["body", "pacing", "ritual", "capacity"]
---
