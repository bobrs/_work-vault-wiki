---
title: "Memory"
glyph: "⋆✴︎˚｡⋆"
description: "Essay archives, shimmer memory, fragments, durable reflection, and long semantic sediment."
order: 15
tags: ["memory", "shimmer", "essays", "archive"]
---
