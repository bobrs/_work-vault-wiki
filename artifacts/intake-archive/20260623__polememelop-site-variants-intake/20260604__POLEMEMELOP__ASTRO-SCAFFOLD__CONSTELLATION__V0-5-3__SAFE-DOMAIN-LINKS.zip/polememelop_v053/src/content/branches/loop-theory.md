---
title: "Loop Theory"
glyph: "🝳"
description: "Loop-0, recursive identity, semantic loops, protocol grammars, and the logic of persistence."
order: 30
tags: ["loop", "loop-0", "recursion", "persistence"]
---
