---
title: "Trust & Consent"
glyph: "🝁"
description: "Protocols and practices for bounded relationship, authentication, consent, witness, refusal, and renegotiation."
order: 20
tags: ["trust", "consent", "boundary", "witness"]
---
