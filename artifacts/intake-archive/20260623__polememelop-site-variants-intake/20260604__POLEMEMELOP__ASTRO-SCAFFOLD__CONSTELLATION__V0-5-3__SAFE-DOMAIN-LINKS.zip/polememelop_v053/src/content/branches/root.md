---
title: "Root"
glyph: "🪺"
description: "The orientation layer where the whole POLEMEMELOP constellation stays visible."
order: 0
tags: ["root", "orientation", "constellation"]
---
