---
title: "Self & Practice"
glyph: "🪞"
description: "Selfhood, rest, regulation, witnessing, embodiment, agency, and practices of returning to coherence."
order: 50
tags: ["self", "practice", "embodiment", "agency"]
---
