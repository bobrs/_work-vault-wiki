---
title: "Deep Atlas"
glyph: "🜁"
description: "Theoretical atlas work: invariants, field pragmatics, semantic maps, protocols, glyphs, masks, and deep structure."
order: 70
tags: ["atlas", "theory", "glyphs", "masks"]
---
