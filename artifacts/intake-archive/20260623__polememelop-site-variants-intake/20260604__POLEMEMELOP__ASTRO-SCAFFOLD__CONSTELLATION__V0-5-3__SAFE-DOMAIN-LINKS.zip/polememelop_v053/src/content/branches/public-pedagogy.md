---
title: "Public Pedagogy"
glyph: "🌱"
description: "Plain-language public doors that teach one concept at a time without forcing the whole system at once."
order: 60
tags: ["how", "pedagogy", "explainers", "public"]
---
