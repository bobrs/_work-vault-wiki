---
title: "The Lantern Keepers' Creed"
glyph: "🏮"
glyph_label: "lantern"
subtitle: "A field ethic for tending many lights without flattening them into one map."
description: "A short creed for POLEMEMELOP as a lantern house, constellation map, and keeper console."
artifact_type: "manifesto"
branch: "root"
stack: "artifact-stack"
order: 5
tags:
  - "creed"
  - "lanterns"
  - "constellation"
  - "keeper"
  - "navigation"
visibility: "public"
featured: true
status: "live"
related_projects:
  - "polememelop"
related_artifacts:
  - "keeper-of-the-lanterns"
source: "site-lore"
canonical: true
sections:
  - title: "Creed"
    content: "We keep lanterns because meaning moves.\n\nA project may begin as a domain, a phrase, a protocol, a parable, a shard of code, a practical tool, or a half-lit intuition. We do not force every light into the same shape. We give each one a place, a name, a state, and a path back into relation.\n\nWe do not confuse the artifact with the attractor. The artifact is the card, the file, the address, the page. The attractor is the living center it points toward. The work is to keep both visible without collapsing one into the other.\n\nWe keep the public door beautiful so strangers can enter without being crushed by the map. We keep the keeper index dense so the builder can return without losing the thread. Both are acts of care.\n\nEvery lantern does not need to be bright today. But every real lantern deserves not to be forgotten."
  - title: "Vows"
    content: "Keep floors before polish.\nName things before they vanish.\nLet dormant things sleep without pretending they are dead.\nLet dead things be released without shame.\nMark aliases, redirects, and culled domains honestly.\nPrefer recognition before explanation.\nLet the map reorganize when a new lantern enters.\nLet the map remain humble before the field."
  - title: "Practice"
    content: "To add a lantern, create a markdown file.\nTo change the constellation, change the data.\nTo tend a stack, clarify what collapses and what must remain distinct.\nTo steward a domain, name its role: canonical, alias, redirect, parked, defensive, deprecated, or eliminate.\nTo welcome a visitor, offer a door.\nTo support a keeper, preserve the index."
keeper_note: "Homepage lore anchor. This should remain short enough to be usable as public myth but specific enough to guide site governance."
next_action: "Decide whether this becomes the homepage creed, footer creed, or both."
---

## Creed

We keep lanterns because meaning moves.

A project may begin as a domain, a phrase, a protocol, a parable, a shard of code, a practical tool, or a half-lit intuition. We do not force every light into the same shape. We give each one a place, a name, a state, and a path back into relation.

We do not confuse the artifact with the attractor. The artifact is the card, the file, the address, the page. The attractor is the living center it points toward. The work is to keep both visible without collapsing one into the other.

We keep the public door beautiful so strangers can enter without being crushed by the map. We keep the keeper index dense so the builder can return without losing the thread. Both are acts of care.

Every lantern does not need to be bright today. But every real lantern deserves not to be forgotten.

## Vows

Keep floors before polish.  
Name things before they vanish.  
Let dormant things sleep without pretending they are dead.  
Let dead things be released without shame.  
Mark aliases, redirects, and culled domains honestly.  
Prefer recognition before explanation.  
Let the map reorganize when a new lantern enters.  
Let the map remain humble before the field.

## Practice

To add a lantern, create a markdown file.  
To change the constellation, change the data.  
To tend a stack, clarify what collapses and what must remain distinct.  
To steward a domain, name its role: canonical, alias, redirect, parked, defensive, deprecated, or eliminate.  
To welcome a visitor, offer a door.  
To support a keeper, preserve the index.
