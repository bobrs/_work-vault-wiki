---
title: "Reaction Coaster"
glyph: "🍻"
glyph_label: "coaster"
subtitle: "Smart alcohol pacing, no app required."
description: "A no-app smart coaster for alcohol pacing that uses reflex checks and ephemeral consent to support safer social drinking."
artifact_type: "prototype"
branch: "embodiment"
stack: "consent-stack"
status: "seed"
visibility: "public"
featured: true
order: 40
tags: ["prototype", "alcohol", "pacing", "ephemeral-trust", "consent", "hospitality"]
related_projects: ["consentfulcybernetics", "humankey", "rewildyourself"]
source: "Reaction_Coaster_Teaser_Simple_Final.docx"
sections:
  - title: "What"
    content: |
      The Reaction Coaster is a simple physical device that helps people pace alcohol consumption based on real-time feedback from their own body.

      It works without an app, login, or wearable, making it easy to integrate into bars, events, or social spaces.
  - title: "How"
    content: |
      A person places a coaster, tab, or token at an ordering station. They tap to request a drink. A quick reflex check begins. The system compares response time to baseline or prior check-ins.

      Fast and steady reaction can allow a full-strength drink. Slowing reaction can trigger reduced strength or delay. No response or opt-out can route to no service or a non-alcoholic option.
  - title: "Consent"
    content: |
      The system is built on ephemeral trust. Patrons are trusted by default. They give consent each time they use the device. No account, ID, history, surveillance, tracking, or judgment is required.
---

This is a physical consent prototype and should be tracked as product, ethics artifact, and possible venue-facing demo.
