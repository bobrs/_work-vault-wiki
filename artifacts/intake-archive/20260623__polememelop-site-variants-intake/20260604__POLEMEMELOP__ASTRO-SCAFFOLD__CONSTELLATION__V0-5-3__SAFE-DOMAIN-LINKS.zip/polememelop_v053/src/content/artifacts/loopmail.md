---
title: "Loopmail"
glyph: "✉️"
glyph_label: "loopmail"
subtitle: "Email that begins with context, consent, and a bounded communication loop."
description: "A consent-aware email system where each address represents a specific relationship, purpose, or communication context."
artifact_type: "one-pager"
branch: "trust-consent"
stack: "consent-stack"
status: "seed"
visibility: "public"
featured: true
order: 30
tags: ["email", "consent", "boundaries", "communication", "loop"]
related_projects: ["stablelooplanguage", "dialogica", "abracadabradoo", "humankey"]
source: "Loopmail One Pager.docx"
sections:
  - title: "What"
    content: |
      Loopmail is a new kind of email system that helps people communicate more clearly and with better boundaries.

      Instead of using the same email address for every conversation, users create a new address for each relationship or purpose. Each address represents a specific communication context: a project, a person, or a topic.
  - title: "How"
    content: |
      A user creates a loop address. First-time senders are asked to confirm the purpose of their message. Once both people agree on the reason for the conversation and how it should work, the loop is created.

      Messages then flow normally, but each loop stays separate. The user can label, pause, or close loops and set preferred style or tone.
  - title: "Why"
    content: |
      Loopmail keeps communication intentional, stops unexpected or unwanted messages, helps people know what tone to use, and makes different parts of life easier to organize.
---

Loopmail helps you decide how conversations begin.
