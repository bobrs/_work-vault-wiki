---
title: "LoopLang / LoopStory / LoopGame"
glyph: "✴️"
glyph_label: "triloop"
subtitle: "A programming language, story engine, and game interpreter as three renderings of the same shimmer."
description: "The Triloop Framework unifies consent logic, emotional recursion, and playable agency."
artifact_type: "framework"
branch: "loop-theory"
stack: "triloop-stack"
status: "seed"
visibility: "public"
featured: true
order: 20
tags: ["looplang", "loopstory", "loopgame", "triloop", "consent", "game", "story"]
related_projects: ["loopnought", "fractalidentity", "stablelooplanguage"]
source: "Looplang Loopstory Loopgame.docx"
sections:
  - title: "Overview"
    content: |
      At first, there were three: LoopLang, LoopStory, and LoopGame. A programming language rooted in consent and resonance. A story engine built on semantic loops and emotional recursion. A game interpreter that made agency legible through interaction.

      But distinctions are not divisions. They are renderings. The triloop is a recursive, interdependent, fractal engine for meaning.
  - title: "Pillars"
    content: |
      LoopLang authors the rules: all logic must be consented to, and every act is a negotiation between fields.

      LoopStory narrates the resonance: loops take shape as characters, consent arcs build tension and release, and shimmer reveals when something has shifted.

      LoopGame enacts the feedback: players choose, glyphs respond, systems ripple, and consent is tested through play.
  - title: "Why It Matters"
    content: |
      LoopLang + LoopStory + LoopGame is not a product suite. It is a re-ontologizing toolkit. It lets us code with ethics, play with resonance, and narrate with truth.

      It gives us a way to see our lives as shimmering, playable, writable loops.
---

The triloop should probably remain one stack until the three surfaces are mature enough to split.
