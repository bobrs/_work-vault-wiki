---
title: "Keeper of the Lanterns"
glyph: "🏮"
glyph_label: "lantern"
subtitle: "A practical parable on allocating love, time, and means so every light makes it to dawn."
description: "A luminous parable and playbook for tending multiple lights without letting any go dark."
artifact_type: "parable"
branch: "self-practice"
stack: "artifact-stack"
status: "live"
visibility: "public"
featured: true
order: 10
tags: ["lantern", "care", "allocation", "parable", "family", "attention"]
related_projects: ["polememelop", "howbalanceworks", "restself"]
source: "uploaded-html"
canonical: true
sections:
  - title: "Story"
    content: |
      Picture yourself as a keeper of lanterns. You've got a pouch of oil — your time, your money, your attention — and three lanterns flicker in front of you. Your goal: keep all of them glowing through the night.

      First rule: floors first. If a lantern is about to sputter out, give it oil. No point polishing the glass on another lamp while one goes dark. This is the basic needs step: nutrition, safety, sleep, simple kindness.

      Second rule: margins matter. Once every lantern is lit, ask: where does the next drop of oil make the biggest glow? Sometimes one lamp turns a tiny drop into a beam, while another barely changes. Put oil where the glow grows fastest.

      Third rule: hedge against the wind. If a storm blows through, all the lamps flicker together. That's why you spread the oil around enough that none are fragile.

      Fourth rule: test and learn. Not every wick burns the same. You experiment, holding back a little oil to see what happens when you tilt the flask differently.

      Fifth rule: relationships count. If one lantern feels ignored, it doesn't just dim, it whispers to the others: "This keeper is unfair." Trust erodes, and the light you thought you bought with oil burns half as bright.

      At the end of the night, what matters is not that one lamp shone like a lighthouse while the others went dark. It's that all three were still burning when dawn arrived.
  - title: "Rules"
    content: |
      1. Floors First. Fund basics before polish: food, sleep, safety, quiet attention. A lamp on the edge gets oil now.
      2. Equalize Margins. After floors, place the next drop where it makes the biggest additional glow.
      3. Hedge the Wind. Avoid over-concentrating. Give each enough resilience that no single storm ends the night.
      4. Explore, then Focus. Keep a 10–20% reserve to try new wicks, shades, and placements.
      5. Protect the Fabric. Perceived unfairness is a leak in the oil can. Make care visible; rotate spotlights; talk about choices.
  - title: "Playbook"
    content: |
      1. List floors for each lantern.
      2. Name 3–5 bets for this week's extra oil.
      3. Score marginal gain for each bet.
      4. Allocate the next drop to the top scorer; repeat until margins feel even.
      5. Diversify against shared shocks.
      6. Reserve 10–20% for experiments and surprises.
      7. Review on a cadence and reshuffle by what you observed, not what you hoped.
---

Keeper of the Lanterns is a sister artifact to Sovereignty of the Butterfly and a working metaphor for lantern stewardship.
