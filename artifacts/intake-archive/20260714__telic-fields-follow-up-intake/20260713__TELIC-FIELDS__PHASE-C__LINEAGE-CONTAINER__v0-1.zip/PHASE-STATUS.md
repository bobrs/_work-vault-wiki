# A–K Roadmap Status

## Phase A — Provenance Package

Status: complete and archived.

Completed:

- root transcript preserved by the human author;
- session compression;
- glossary and claim register;
- lineage map;
- candidate concept-page package.

## Phase B — Formal Wiki Intake

Status: blocked at B.2.

Completed:

- intake-readiness packet;
- hashes for available derivatives;
- proposed inventory records;
- proposed lineage edges;
- operational checklist.

Pending:

- attach the exact root transcript to the working environment or repository;
- record original filename, hash, artifact ID, paths, and public/private disposition;
- run actual repository inventory and validation;
- commit the witnessed intake state.

## Phase C — Wiki Lineage Container

Status: staged draft complete in this package.

Created:

- project landing page;
- lineage page;
- sources page;
- open-questions page;
- projects-index patch.

These files should not be installed as finalized repository state until Phase B's root intake is resolved. They are safe as candidate semantic drafts because every unresolved provenance field remains visibly pending.

## Phase D — Artifact Pages and Concept Installation

Status: next executable phase after B and C repository installation.

## Phases E–K

Not started.

## Next step

Attach or ingest the exact root transcript, complete Phase B, then install and validate this Phase C container.
