# Telic Field Papers — Phase C Lineage Container

This package stages the four-page wiki lineage container for **The Telic Field Papers**.

## Included

```text
wiki/projects/telic-field-papers/index.md
wiki/projects/telic-field-papers/lineage.md
wiki/projects/telic-field-papers/sources.md
wiki/projects/telic-field-papers/open-questions.md
patches/projects-index-addition.md
PHASE-STATUS.md
```

## Repository alignment

The pages follow the current Work Vault project-page style:

- plain Markdown rather than source-artifact YAML;
- explicit status and source-role lines;
- working read and current-shape language;
- related project and attractor bridges;
- next-action sections;
- no silent canon promotion.

## Important boundary

Phase B is not complete because the root transcript's exact file identity and repository record remain pending.

This package is therefore a **staged semantic draft**, not a completed repository mutation.

## Installation sequence

1. complete root transcript intake;
2. confirm standard-named source paths;
3. place these pages under `wiki/projects/telic-field-papers/`;
4. update unresolved links;
5. apply the projects-index addition;
6. install the candidate concept pages;
7. run build and validation;
8. inspect search and graph output;
9. commit the witnessed state.
