# Proposed Projects Index Addition

This patch is staged only. Do not apply it until the lineage container is installed and repository links validate.

Add under `## Top-Level Project Pages`:

```markdown
- [The Telic Field Papers](telic-field-papers/index.md)
```

Possible placement:

```markdown
- [Semantic Integrity](semantic-integrity/index.md)
- [The Telic Field Papers](telic-field-papers/index.md)
- [Shimmery Memory](shimmerymemory/index.md)
```

The exact placement may change after cross-index review.
