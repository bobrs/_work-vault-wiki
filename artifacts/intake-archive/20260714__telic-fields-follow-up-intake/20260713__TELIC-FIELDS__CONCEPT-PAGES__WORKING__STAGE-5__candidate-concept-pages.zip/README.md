# Stage 5 — Candidate Concept Pages

This bundle contains the first six wiki-ready concept pages for **The Telic Field Papers**:

- Telic Fields
- Telic Projection
- Polytelometric Navigation
- Constitutional Self
- Context Carrying Capacity
- Semantic Polytelometry

All pages are marked:

```text
status: candidate
processing_tier: 4
content_canon_status: unset
```

They are derived working pages, not source artifacts and not canon declarations.

## Intended placement

Copy the `wiki/concepts/` directory contents into the corresponding Work Vault Wiki concept paths after:

1. confirming no existing page conflicts;
2. confirming the root transcript's archived and standard-named paths;
3. updating source links;
4. checking relative links against the site's build system;
5. running the repository build and validation commands.

## Provenance

The root transcript remains the primary witness source.

The session compression, glossary, lineage map, and these concept pages are descendant interpretations.
