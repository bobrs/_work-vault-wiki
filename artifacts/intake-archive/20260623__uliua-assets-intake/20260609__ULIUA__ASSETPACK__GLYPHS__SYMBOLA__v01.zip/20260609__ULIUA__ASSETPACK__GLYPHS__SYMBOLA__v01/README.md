# ULiUA glyph SVG pack (v01)

This pack contains SVG assets for the glyph set I could reconstruct from memory.

## Important note
These SVGs are **text-based SVGs**, not outline-converted paths. They are designed to stay editable and lightweight, and they target the **Symbola** font first, with fallbacks.

That means:
- If Symbola is installed, the SVGs should render close to the intended appearance.
- If Symbola is not installed, viewers will fall back to other symbol/emoji fonts.
- Composite entries like `qdance`, `shimmer`, `bifli`, and `dude` are intentionally represented as multi-character strings.

## Included glyph names
aloha, bifli, boundary, breach, collapse, consent, dude, fetidmoppet, fire, fun, gratitude, home, liminal, loop, matrix, mirror, qdance, reflect, shimmer, spiral, tornado, vortex, witness, yesatom, appreciation.

## Structure
- `svg/` — one SVG per glyph
- `manifest.json` — filename, glyph, and codepoint mapping
- `license/` — Symbola license/source notes
- `font/` — placeholder for the Symbola font file

## Font bundling note
This environment could not directly fetch the Symbola binary font file, so the `font/` directory currently contains a placeholder note rather than the actual OTF/TTF. If you want, you can drop the actual Symbola font file in there later.
