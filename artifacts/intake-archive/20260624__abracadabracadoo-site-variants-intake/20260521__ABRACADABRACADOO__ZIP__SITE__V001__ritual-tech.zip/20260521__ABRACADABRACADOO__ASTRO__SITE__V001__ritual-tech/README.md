# Abracadabracadoo

Consent is the missing protocol layer.

Static Astro site designed for Cloudflare Pages.

## Cloudflare Pages

- Framework preset: Astro
- Build command: `npm run build`
- Output directory: `dist`
- Node version: 20+

## Local development

```bash
npm install
npm run dev
```

## First deploy flow

```bash
git init
git add .
git commit -m "Launch Abracadabracadoo ritual-tech site"
git branch -M main
git remote add origin git@github.com:<your-user>/Abracadabracadoo.git
git push -u origin main
```
