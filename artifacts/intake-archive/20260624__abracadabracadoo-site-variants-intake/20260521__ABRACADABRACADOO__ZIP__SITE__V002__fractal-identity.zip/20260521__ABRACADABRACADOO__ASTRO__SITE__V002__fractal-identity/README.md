# Abracadabracadoo

Consent is the missing protocol layer.

Static Astro site designed for Cloudflare Pages. V002 adds Fractal Identity as a first-class companion protocol in the consent-native stack.

## Pages included

- `/` home
- `/manifesto/` manifesto
- `/protocol/` Abracadabracadoo protocol
- `/loops/` consent, witness, boundary, forgetting, and group loops
- `/fractal-identity/` context-sized selfhood and identity mesh
- `/humankey/` relationship-sized trust
- `/for-ai/` consentful interpretation and derivative cognition
- `/docs/` protocol library and downloads
- `/spread/` copyable language

## Cloudflare Pages

- Framework preset: Astro
- Build command: `npm run build`
- Output directory: `dist`
- Node version: 20+

## Local development

```bash
npm install
npm run dev
```

## First deploy flow

```bash
git init
git add .
git commit -m "Launch Abracadabracadoo ritual-tech site"
git branch -M main
git remote add origin git@github.com:<your-user>/Abracadabracadoo.git
git push -u origin main
```
