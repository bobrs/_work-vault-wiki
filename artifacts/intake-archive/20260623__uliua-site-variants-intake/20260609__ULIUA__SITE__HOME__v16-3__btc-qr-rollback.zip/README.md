# ULiUA site v16.2

Patch from v16.1.

Changes:
- Removed the color lab countdown/auto-hide timer code.
- The lab now opens and stays open until the visitor explicitly chooses Hide.
- Kept the hidden default state, Show pulse, BTC donation panel, Abracadoo bridge card, Consent Seed references, and v16.1 BTC address.

BTC address:
3MXEGJCxpaSZbdrBWwpN9ghsj6wdyZqUAZ


## v16.3
Restored the uploaded Coinbase/BTC QR graphic while keeping the updated BTC address text: 3MXEGJCxpaSZbdrBWwpN9ghsj6wdyZqUAZ.
