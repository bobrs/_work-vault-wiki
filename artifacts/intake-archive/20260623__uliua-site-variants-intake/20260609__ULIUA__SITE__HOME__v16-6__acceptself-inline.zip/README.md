# ULiUA Site Bundle v16.5

Build: v16.5-acceptself-bridge

Changes from v16.4:
- Added AcceptSelf.com as the self-application bridge for Unconditional Acceptance.
- Added the 🜁 AcceptSelf mark in the Where this fits card.
- Added AcceptSelf.com to visible links and machine-readable references.

Includes:
- index.html
- consent-seed.html
- L3-ULIUA-01.consent-seed.v1.1.json
- assets/uliua-wordmark.png
- assets/abracadoo-hometown.png
- assets/btc-donation-qr.png


Patch v16.6: moved AcceptSelf.com out of the support/bridge area and into an inline stylized card inside the main Message panel.
