# ULiUA Site Bundle v16.5

Build: v16.5-acceptself-bridge

Changes from v16.4:
- Added AcceptSelf.com as the self-application bridge for Unconditional Acceptance.
- Added the 🜁 AcceptSelf mark in the Where this fits card.
- Added AcceptSelf.com to visible links and machine-readable references.

Includes:
- index.html
- consent-seed.html
- L3-ULIUA-01.consent-seed.v1.1.json
- assets/uliua-wordmark.png
- assets/abracadoo-hometown.png
- assets/btc-donation-qr.png


Patch v16.6: moved AcceptSelf.com out of the support/bridge area and into an inline stylized card inside the main Message panel.


Patch v16.7: added “Simple, direct acceptance of what is.” to the Message panel.


Patch v16.8: made the Attractor Glyphs section collapsed by default under a compact teaser with an explicit “Open the glyph guide” control.


Patch v16.9: corrected Message panel spacing by removing the narrow poster-copy constraint, keeping the AcceptSelf inset in normal flow, and overriding its typography so it does not inherit poster headline sizing.
