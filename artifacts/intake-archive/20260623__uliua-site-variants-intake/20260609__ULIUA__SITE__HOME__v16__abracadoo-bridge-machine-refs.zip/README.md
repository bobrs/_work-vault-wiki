# ULiUA v16 bundle

Primary file: `index.html`

Included references:
- `consent-seed.html` — human-readable Consent Seed page.
- `L3-ULIUA-01.consent-seed.v1.1.json` — machine-readable Consent-First Structural Charter.
- `assets/abracadoo-hometown.png` — Abracadoo / HumanKey bridge card image.
- `assets/uliua-wordmark.png` — ULiUA wordmark source used in the page.
- `assets/btc-donation-qr.png` — BTC donation QR image.

The page includes `<link rel="alternate">` references and JSON-LD pointing to the Consent Seed and Consent Charter files.
