# ULiUA v16.4 — Already Welcome Default

This bundle carries forward v16.3, keeps the uploaded Coinbase BTC QR graphic, keeps the updated BTC address text, keeps the no-auto-hide color lab behavior, and changes the bare-page default color field to the “Already Welcome” theme.

Included:
- index.html
- consent-seed.html
- L3-ULIUA-01.consent-seed.v1.1.json
- assets/abracadoo-hometown.png
- assets/uliua-wordmark.png
- assets/btc-donation-qr.png

BTC address shown on page:
3MXEGJCxpaSZbdrBWwpN9ghsj6wdyZqUAZ
