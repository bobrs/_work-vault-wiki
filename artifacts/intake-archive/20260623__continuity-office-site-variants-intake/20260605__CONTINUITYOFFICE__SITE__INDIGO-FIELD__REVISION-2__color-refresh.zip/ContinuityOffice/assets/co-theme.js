(() => {
  const THEME_HREFS = {
    INSTITUTIONAL: "/assets/css/theme-institutional.css",
    MODERN: "/assets/css/theme-modern.css",
    MINIMAL: "/assets/css/theme-minimal.css"
  };

  const STORAGE_KEY = "coTheme";

  function normalizeTheme(value) {
    const raw = String(value || "").toUpperCase();
    return Object.prototype.hasOwnProperty.call(THEME_HREFS, raw) ? raw : "INSTITUTIONAL";
  }

  function applyTheme(value) {
    const theme = normalizeTheme(value);
    const link = document.getElementById("themeStylesheet");
    if (link) link.setAttribute("href", THEME_HREFS[theme]);
    document.documentElement.setAttribute("data-theme", theme.toLowerCase());
    try { localStorage.setItem(STORAGE_KEY, theme); } catch (_) {}
    return theme;
  }

  function storedTheme() {
    try { return localStorage.getItem(STORAGE_KEY); } catch (_) { return null; }
  }

  document.addEventListener("DOMContentLoaded", () => {
    const select = document.getElementById("themeSelect");
    const initial = normalizeTheme(storedTheme() || (select && select.value));
    applyTheme(initial);
    if (select) {
      select.value = initial;
      select.addEventListener("change", (event) => applyTheme(event.target.value));
    }
  });
})();
