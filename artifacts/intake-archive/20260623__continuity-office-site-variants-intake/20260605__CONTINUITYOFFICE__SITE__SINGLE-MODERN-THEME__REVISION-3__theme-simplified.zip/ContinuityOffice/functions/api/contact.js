/**
 * Cloudflare Pages Function: /api/contact
 * - Validates Turnstile
 * - Honeypot + basic validation
 * - Sends email via Resend
 * - Redirects to /thank-you/
 *
 * Env vars (Cloudflare Pages -> Settings -> Environment variables):
 *  Secrets:
 *   - TURNSTILE_SECRET
 *   - RESEND_API_KEY
 *  Plain (optional):
 *   - CONTACT_TO (default hello@continuityoffice.com)
 *   - CONTACT_FROM (default hello@continuityoffice.com)  <-- must be verified in Resend
 *   - CONTACT_SUBJECT_PREFIX (default "Continuity Office")
 */

function escapeText(v) {
  return String(v ?? "").replace(/\r\n/g, "\n").trim();
}

function safeHeader(v, fallback = "") {
  const s = String(v ?? fallback).replace(/[\r\n]+/g, " ").trim();
  return s || fallback;
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || "").trim());
}

async function verifyTurnstile({ token, ip, secret }) {
  if (!token) return { ok: false, error: "missing-token" };
  if (!secret) return { ok: false, error: "missing-secret" };

  const form = new FormData();
  form.append("secret", secret);
  form.append("response", token);
  if (ip) form.append("remoteip", ip);

  const resp = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
    method: "POST",
    body: form,
  });

  if (!resp.ok) return { ok: false, error: `verify-http-${resp.status}` };

  const data = await resp.json();
  return { ok: !!data.success, data };
}

async function sendResend({ apiKey, to, from, subject, text, replyTo }) {
  const payload = {
    from,
    to: [to],
    subject,
    text,
    // Resend supports reply_to
    reply_to: replyTo || undefined,
  };

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify(payload),
  });

  const detail = await res.text().catch(() => "");
  return { ok: res.ok, status: res.status, detail };
}

function redirectResponse(location, status = 303) {
  return new Response(null, {
    status,
    headers: { Location: location, "Cache-Control": "no-store" },
  });
}

function textResponse(message, status = 400) {
  return new Response(message, {
    status,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}

export async function onRequestGet() {
  // If someone navigates to /api/contact directly
  return redirectResponse("/#contact", 302);
}

export async function onRequestPost(context) {
  const { request, env } = context;

  const contentType = request.headers.get("content-type") || "";
  if (!contentType.includes("application/x-www-form-urlencoded") && !contentType.includes("multipart/form-data")) {
    return textResponse("Unsupported content type.", 415);
  }

  const formData = await request.formData();

  // Honeypot
  const honeypot = escapeText(formData.get("website"));
  const redirectTo = safeHeader(formData.get("redirect"), "/thank-you/");
  if (honeypot) return redirectResponse(redirectTo, 303);

  // Required fields
  const name = escapeText(formData.get("name"));
  const email = escapeText(formData.get("email"));
  const org = escapeText(formData.get("org"));
  const lane = escapeText(formData.get("lane"));
  const role = escapeText(formData.get("role"));
  const timeline = escapeText(formData.get("timeline"));
  const message = escapeText(formData.get("message"));

  if (!name || !email || !message || !lane) return textResponse("Missing required fields.", 400);
  if (!isValidEmail(email)) return textResponse("Please enter a valid email address.", 400);

  // Turnstile
  const token = escapeText(formData.get("cf-turnstile-response"));
  const ip =
    request.headers.get("CF-Connecting-IP") ||
    request.headers.get("X-Forwarded-For") ||
    "";

  const turnstile = await verifyTurnstile({
    token,
    ip: String(ip).split(",")[0].trim(),
    secret: env.TURNSTILE_SECRET,
  });

  if (!turnstile.ok) {
    return textResponse("Verification failed. Please refresh and try again.", 403);
  }

  // Email routing
  const to = env.CONTACT_TO || "hello@continuityoffice.com";
  const from = env.CONTACT_FROM || "hello@continuityoffice.com";
  const prefix = env.CONTACT_SUBJECT_PREFIX || "Continuity Office";
  const subject = safeHeader(`${prefix} — New inquiry: ${lane}`);

  const text = [
    "New inquiry via continuityoffice.com",
    "",
    `Name: ${name}`,
    `Email: ${email}`,
    org ? `Organization: ${org}` : "Organization: (not provided)",
    `Lane: ${lane}`,
    role ? `Role: ${role}` : "Role: (not provided)",
    timeline ? `Timeline: ${timeline}` : "Timeline: (not provided)",
    "",
    "Message:",
    message,
    "",
    `Timestamp (UTC): ${new Date().toISOString()}`,
    `IP: ${String(ip).split(",")[0].trim() || "(unknown)"}`,
  ].join("\n");

  if (!env.RESEND_API_KEY) {
    console.log("Missing RESEND_API_KEY env var.");
    return textResponse("Delivery is not configured. Please email hello@continuityoffice.com.", 503);
  }

  const mail = await sendResend({
    apiKey: env.RESEND_API_KEY,
    to,
    from,
    subject,
    text,
    replyTo: email,
  });

  if (!mail.ok) {
    // Log detail for you, but don’t show it to the user
    console.log("resend failed:", mail.status, mail.detail);
    return textResponse("Message received but delivery failed. Please email hello@continuityoffice.com.", 502);
  }

  return redirectResponse(redirectTo, 303);
}