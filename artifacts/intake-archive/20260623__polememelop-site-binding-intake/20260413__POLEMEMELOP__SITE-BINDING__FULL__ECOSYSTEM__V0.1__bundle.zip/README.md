# Site Binding Starter Bundle

This bundle contains the first-pass multi-site identity layer for the Polememelop ecosystem.

## Contents

- `.well-known/ecosystem.json` — canonical ecosystem graph root
- `templates/` — footer snippets, head snippets, JSON-LD, and site-identity template
- `instructions/site-binding-implementation.md` — implementation notes and rollout order
- `instructions/per-site-rollout-checklist.md` — quick checklist for each site

## Suggested rollout order

1. Put `.well-known/ecosystem.json` on `polememelop.com`
2. Add the head snippet and footer snippet to core deployed sites
3. Add per-site `/.well-known/site-identity.json` files
4. Keep status fields honest: live, deployed, experimental, reserved, shelved, alias, client_related
