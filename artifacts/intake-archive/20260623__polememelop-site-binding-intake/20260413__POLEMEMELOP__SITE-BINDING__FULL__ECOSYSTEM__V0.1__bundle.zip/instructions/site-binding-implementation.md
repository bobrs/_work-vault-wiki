# Site Binding Implementation Guide

## Goal

Create a shared identity layer across the Polememelop constellation without flattening each site into generic branding.

## Deploy on Polememelop

- Add `.well-known/ecosystem.json` at the site root
- Add the umbrella JSON-LD template to the homepage
- Add visible links to a small set of core sites

## Deploy on each project site

1. Add `templates/head-snippet-project.html` to the `<head>` and replace `ecosystem:site-id` and `ecosystem:site-role`
2. Add `templates/footer.css` to the site stylesheet
3. Add one footer snippet just above `</footer>` or at the end of the page footer
4. Add a site-specific `/.well-known/site-identity.json` using the template
5. Add a project JSON-LD block to the homepage

## Which footer where

- `footer-minimal.html` — minimal / attractor-heavy sites like LoopNought
- `footer-standard.html` — explanatory or infrastructure sites like Quantum Invariants
- `footer-umbrella.html` — Polememelop itself

## Status discipline

Keep site status honest:
- live
- deployed
- experimental
- reserved
- shelved
- alias
- client_related

## Suggested next additions

- `/.well-known/site-identity.json` on every deployed site
- optional `related projects` block on umbrella or navigation-heavy sites
- optional ecosystem sitemap later if you want a machine-crawlable index
