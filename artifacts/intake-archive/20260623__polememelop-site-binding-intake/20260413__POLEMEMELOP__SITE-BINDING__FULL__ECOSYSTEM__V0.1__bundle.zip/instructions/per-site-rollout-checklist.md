# Per-Site Rollout Checklist

- [ ] Confirm site name and canonical URL
- [ ] Choose status
- [ ] Choose one or two roles
- [ ] Add head snippet
- [ ] Add footer CSS
- [ ] Add correct footer snippet
- [ ] Add homepage JSON-LD
- [ ] Create `/.well-known/site-identity.json`
- [ ] Add or update any site-specific machine manifests already in use
- [ ] Verify local identity still feels native after the addition
