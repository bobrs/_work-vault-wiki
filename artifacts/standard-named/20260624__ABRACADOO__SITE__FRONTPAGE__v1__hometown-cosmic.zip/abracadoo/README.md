# Abracadoo static landing page

This folder contains a production-oriented static HTML/CSS implementation of the Abracadoo landing page direction.

## Files

- `index.html` - the landing page markup
- `styles.css` - responsive styling and brand system
- `assets/abracadoo-logo-lockup.png` - generated logo lockup
- `assets/abracadoo-app-placeholder.png` - current app UI placeholder screenshot
- `assets/design-reference.png` - the visual mockup reference image

## Run locally

Open `index.html` directly in a browser, or serve the folder with any static server:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`.

## Deploy

For Cloudflare Pages, Netlify, GitHub Pages, or similar static hosting, deploy the folder as-is. No build step is required.

If converting to Astro later, the main sections map cleanly into components:

- `Header.astro`
- `Hero.astro`
- `FeatureCards.astro`
- `HowItWorks.astro`
- `ProtocolBand.astro`
- `CTA.astro`
- `Footer.astro`
