# Abracadoo.com front page — v0.2 hometown-cosmic hero

This pass turns the static north-star mockup into a real responsive front page structure.

## What changed from v0.1

- Replaced the generic orbit/SaaS hero graphic with a coded hometown-cosmic scene.
- Kept headline, subheadline, nav, buttons, and trust strip as real HTML text.
- Added a reusable SVG `trust-path` layer so the loop language is not locked into a flat bitmap.
- Added a CSS-built hometown layer: sunset glow, hills, water tower, steeple, houses, porchlight warmth, streetlamps.
- Kept the product preview as an HTML/CSS component so it can later converge with the live app skin.
- Added design tokens that can eventually be shared with the app skin without forcing the app to inherit the full illustrated homepage.

## Files

- `index.html` — static HTML page.
- `styles.css` — full visual system and responsive CSS.
- `assets/20260610__ABRACADOO__REFERENCE__MOCKUP__V0-2__HOMETOWN-COSMIC.png` — visual reference only, not used by the page.

## Links currently wired

- Open the App: `https://app.abracadoo.app/`
- Protocol / GitHub: `https://github.com/bobrs/abracadoo-code`
- Footer project link: `https://consentfulcybernetics.com`


## v0.3 pass notes

- Increased the warm glow behind the hometown houses/horizon by roughly 15%.
- Removed the complex galaxy/nebula-style space graphic treatment from the hero.
- Preserved the simpler sky/starfield effect, trust path, houses, typography, and copy.


## v0.6 notes

- Removed the `hero-world::before` and `hero-world::after` overlay treatments.
- Restored the distant hills behind the houses to ground the horizon.
- Restored the coded app preview card in the hero.


## v0.7 changes
- Updated `.distant-hills` to the specified lower, warmer hill treatment.
- Honed the hero subcopy to: 'Abracadoo is a free, open-source app designed to let trust flow in loops and scale from the two of us to the entire universe — one loop at a time. The 🜁 at the beginning of the Semantic Overnet. Welcome.'


## v0.8 notes

- Tuned `.sunset-glow` with the repaired radial-gradient syntax.
- Moved `.product-card` to `right: 150px; bottom: 200px;`.
