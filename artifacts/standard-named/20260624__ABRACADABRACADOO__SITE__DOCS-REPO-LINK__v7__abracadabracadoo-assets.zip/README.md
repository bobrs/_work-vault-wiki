# Abracadabracadoo

Consent is the missing protocol layer.

Static Astro site designed for Cloudflare Pages. V003 adds Fractal Identity as a first-class companion protocol in the consent-native stack.

## Pages included

- `/` home
- `/manifesto/` manifesto
- `/protocol/` Abracadabracadoo protocol
- `/loops/` consent, witness, boundary, forgetting, and group loops
- `/fractal-identity/` context-sized selfhood and identity mesh
- `/humankey/` relationship-sized trust
- `/for-ai/` consentful interpretation and derivative cognition
- `/docs/` protocol library gateway linking to the public `abracadabracadoo-assets` repository
- `/spread/` copyable language

## Cloudflare Pages

- Framework preset: Astro
- Build command: `npm run build`
- Output directory: `dist`
- Node version: 20+

## Local development

```bash
npm install
npm run dev
```

## First deploy flow

```bash
git init
git add .
git commit -m "Launch Abracadabracadoo ritual-tech site"
git branch -M main
git remote add origin git@github.com:<your-user>/Abracadabracadoo.git
git push -u origin main
```


## Consentful Cybernetics parent link

Every page footer includes: **A project of Consentful Cybernetics** linking to https://consentfulcybernetics.com. The homepage also includes a parent-attractor section naming Consentful Cybernetics as the source field for the project.


## Protocol documents

Canonical protocol documents and public assets are maintained in the separate assets repository:

https://github.com/bobrs/abracadabracadoo-assets

This site links to that repository instead of hosting a local copy of the protocol document set.
